# procurement_store.py
# 조달청 낙찰·계약 결과 저장소 — 영업기회(postings)와 분리된 '시장 정보' 테이블
import hashlib
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import text

from db2 import get_engine

TABLE = "procurement_results"
FIELDS = ["kind", "ref_no", "title", "agency", "company", "amount", "rate", "event_date", "url"]


def ensure_table():
    with get_engine().begin() as conn:
        conn.execute(text(f"""
            CREATE TABLE IF NOT EXISTS {TABLE} (
                uniq_key TEXT PRIMARY KEY,
                kind TEXT, ref_no TEXT, title TEXT, agency TEXT, company TEXT,
                amount TEXT, rate TEXT, event_date TEXT, url TEXT,
                created_at TEXT, updated_at TEXT
            )
        """))


def _key(row):
    base = f"{row.get('kind')}|{row.get('ref_no') or row.get('title')}"
    return hashlib.md5(base.encode("utf-8")).hexdigest()


def save_results(rows):
    """낙찰·계약 결과를 한 번에 저장(같은 건은 갱신). 반환: 저장 건수"""
    if not rows:
        return 0
    ensure_table()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    params = []
    for r in rows:
        p = {f: str(r.get(f) or "") for f in FIELDS}
        p["uniq_key"] = _key(r)
        p["now"] = now
        params.append(p)
    with get_engine().begin() as conn:
        conn.execute(text(f"""
            INSERT INTO {TABLE} (uniq_key, kind, ref_no, title, agency, company, amount, rate,
                                 event_date, url, created_at, updated_at)
            VALUES (:uniq_key, :kind, :ref_no, :title, :agency, :company, :amount, :rate,
                    :event_date, :url, :now, :now)
            ON CONFLICT (uniq_key) DO UPDATE SET
                title=excluded.title, agency=excluded.agency, company=excluded.company,
                amount=excluded.amount, rate=excluded.rate, event_date=excluded.event_date,
                url=excluded.url, updated_at=excluded.updated_at
        """), params)
    return len(params)


def load_results(days=30):
    """최근 N일 결과. 테이블이 아직 없으면 빈 표."""
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    try:
        df = pd.read_sql_query(
            text(f"SELECT * FROM {TABLE} WHERE event_date >= :since ORDER BY event_date DESC"),
            get_engine(), params={"since": since},
        )
    except Exception:
        return pd.DataFrame(columns=FIELDS)
    return df
